# Cuidon landing page

Welcome to our repository dedicated to CUIDON's landing page!

This repository was created to help you easily manage and update the contents of your CUIDON landing page. Here you will find resources and tools to edit and customize your page, such as images, texts, videos, and other visual elements.
